g++ main.cpp -o main
g++ main2.cpp -o main2
exit 0
