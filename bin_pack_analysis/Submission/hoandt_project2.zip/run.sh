g++ main.cpp -o proj2 && ./proj2
