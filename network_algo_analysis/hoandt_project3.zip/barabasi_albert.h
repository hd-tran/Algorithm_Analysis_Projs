#ifndef BARABASI_ALBERT_H
#define BARABASI_ALBERT_H

#include "graph.h"
#include "randomGen.h"

Graph create_barabasi_albert_graph(int n, int d);


#endif
