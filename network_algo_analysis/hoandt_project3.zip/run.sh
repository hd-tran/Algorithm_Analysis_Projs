g++ *.cpp -o main && ./main
